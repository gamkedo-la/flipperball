//Utils.js
// eslint-disable-next-line no-unused-vars

function DEBUG_LOG(message) {
    if (DEBUG) {
        console.log(message);
    }
}